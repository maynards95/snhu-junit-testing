import java.util.Date;

public class Appointment {
    private String id;
    private Date appointmentDate;
    private String description;

    //Constructor
    public Appointment(String id, Date appointmentDate, String description) {
        //input validation that will throw an exception if not true
        if (id.length() > 10 || id == null) {
            throw new IllegalArgumentException("Invalid input");
        }
        if (description.length() > 50 || id == null) {
            throw new IllegalArgumentException("Invalid input");
        }
        if (appointmentDate == null || appointmentDate.after(new Date())) {
            throw new IllegalArgumentException("Invalid Date");
        }
        this.id = id;
        this.appointmentDate = appointmentDate;
        this.description = description;
    }

    public Appointment() {

    }

    public static Appointment bookAppointment(String id, Date appointmentDate, String description) {
        // input validation for all three parameters.
        if (id.length() > 10 || id == null) {
            System.out.println("Invalid ID");
            return null;
        }

        if (appointmentDate == null || appointmentDate.after(new Date())) {
            System.out.println("Invalid Appointment Date");
            return null;
        }

        if (description.length() > 50 || description == null) {
            System.out.println("Invalid Description");
            return null;
        }

        return new Appointment(id, appointmentDate, description);
    }

    //GETTERS
    public Date getAppointmentDate() {
        return appointmentDate;
    }
    public String getDescription() {
        return description;
    }
    public String getId() {
        return id;
    }

    //SETTERS
    public void setAppointmentDate(Date appointmentDate) {
        this.appointmentDate = appointmentDate;
    }

    public void setId(String id){this.id = id;}

    public void setDescription(String description) {
        this.description = description;
    }



}