import java.lang.reflect.UndeclaredThrowableException;
import java.util.EmptyStackException;

public class Contact {
    private String contactID = "";
    private String firstName = "";
    private String lastName = "";
    private String phoneNumber = "";
    private String address = "";

    public Contact(String contactId,String fName,String lName,String phoneNumber, String address){
        if(contactId.length() <= 10 && contactId != null) {
            this.contactID = contactId;
        }
        else {
            this.contactID = "Error: please update contact ID";
        }
        this.setFirstName(fName);
        this.setLastName(lName);
        this.setPhoneNumber(phoneNumber);
        this.setAddress(address);
    }

    //SETTERS
    public void setFirstName(String fName) {
        if(fName.length() <= 10 && fName != null) {
            this.firstName = fName;
        }
        else {
            this.firstName = "Error: Please update first name";
        }
    }

    public void setLastName(String lName) {
        if(lName.length() <= 10 && lName != null) {
            this.lastName = lName;
        }
        else {
            this.lastName = "Error: Please update last name";
        }
    }

    public void setPhoneNumber(String phoneNumber) {
        if(phoneNumber.length() < 11 && phoneNumber != null) {
            this.phoneNumber = phoneNumber;
        }
        else {
            this.phoneNumber = "Error: Please update phone number";
        }
    }

    public void setAddress(String address) {
        if(address.length() <= 30 && address != null) {
            this.address = address;
        }
        else {
            this.address = "Error: Please update address";
        }
    }

    //GETTERS
    public String getContactID() {
        return contactID;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getAddress() {
        return address;
    }

    @Override
    public String toString() {
        return "Contact [contactID=" + contactID + ", firstName=" + firstName + ", lastName=" + lastName
                + ", phoneNumber=" + phoneNumber + ", address=" + address + "]";
    }
}