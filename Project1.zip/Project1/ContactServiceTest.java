import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class ContactServiceTest {


    @Test
    public void testAdd()
    {
        ContactService cs = new ContactService();
        Contact sample1 = new Contact("1413252", "Ezra", "May", "22222222", "Fake 24 Ave");
        Contact sample2 = new Contact("14132524", "Ezra", "Smithhhhhhhhhhhhhhh", "4444444444444444", "Fake 24 Ave");
        Contact sample3 = new Contact("14250692", "Ezra", "May", "222222222", "Fake 24 Ave");
        Contact sample4 = new Contact("14132524", "Ezra", "Smithh", "2222222222222222", "Fake 24 Ave");
        //all add contacts so true
        assertEquals(true, cs.addContact(sample1));
        assertEquals(true, cs.addContact(sample2));
        assertEquals(true, cs.addContact(sample3));
        //false because we already have a contact that matches this contactID. They must be unique.
        assertEquals(false, cs.addContact(sample4));

    }

    @Test
    public void testDelete()
    {
        ContactService cs = new ContactService();

        Contact sample1 = new Contact("1413252", "Ezra", "May", "444444444444", "Fake 24 Ave");
        Contact sample2 = new Contact("1309403", "Tod", "Hornsby", "2187123404", "Fake 24 Ave");
        Contact sample3 = new Contact("9752319", "Vil", "Schoenheit", "9215501793", "Fake 24 Ave");

        cs.addContact(sample1);
        cs.addContact(sample2);
        cs.addContact(sample3);
        //true for deleting a contact with the same contactID
        assertEquals(true, cs.deleteContact("1309403"));
        //should equal false because contactID does not exist
        assertEquals(false, cs.deleteContact("1309404"));
        //should equal false because we already deleted the contact
        assertEquals(false, cs.deleteContact("1309403"));
    }

    @Test
    public void testUpdateLastName()
    {
        ContactService cs = new ContactService();

        Contact test1 = new Contact("1413252", "Ezra", "May", "4444444444", "Fake 24 Ave");
        Contact test2 = new Contact("1309403", "Tod", "Hornsby", "2187123404", "Fake 24 Ave");
        Contact test3 = new Contact("9752319", "James", "Weisberg", "9215501793", "Fake 24 Ave");

        cs.addContact(test1);
        cs.addContact(test2);
        cs.addContact(test3);

        assertTrue(cs.updateContactLastName("1413252", "Maynard"));
        assertTrue(cs.updateContactLastName("1309403", "Mayyerd"));
    }

    @Test
    public void testUpdateContactFirstName() throws Exception {
        ContactService cs = new ContactService();

        Contact test1 = new Contact("1413252", "Ezra", "May", "4444444444", "Fake 24 Ave");
        cs.addContact(test1);

        assertTrue(cs.updateContactFirstName("1413252", "Bob"));
    }

    @Test
    public void testUpdateContactNumber() throws Exception {
        ContactService cs = new ContactService();

        Contact test1 = new Contact("1413252", "Ezra", "May", "4444444444", "Fake 24 Ave");
        cs.addContact(test1);

        assertTrue(cs.updateContactNumber("1413252", "2812445596"));
    }

    @Test
    public void testUpdateContactAddress() throws Exception {
        ContactService cs = new ContactService();

        Contact test1 = new Contact("1413252", "Ezra", "May", "4444444444", "Fake 24 Ave");
        cs.addContact(test1);

        assertTrue(cs.updateContactAddress("1413252", "New Address 289"));
    }

}