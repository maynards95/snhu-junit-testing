import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

class AppointmentTest {

    Date currentDate = new Date();
    @Test
    void testAppointment(){
        Appointment task = new Appointment("0123456789",currentDate, "AppointmentDescription1");
        assertTrue(task.getId().equals("0123456789"));
        assertTrue(task.getAppointmentDate().before(new Date()));
        assertTrue(task.getDescription().equals("AppointmentDescription1"));
    }

    @Test
    void testBookAppointment(){
        Appointment apt = new Appointment();
        apt.bookAppointment("1234567890", currentDate, "ApptDescrip2");
        assertTrue(apt.getDescription().equals("ApptDescrip2"));
    }

    @Test
    void testIdTooLong(){
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("0123456789111", currentDate, "AppointmentDescription1");
        });
    }

    @Test
    void testDescriptionTooLong(){
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("0123456789111", currentDate, "AppointmentDescription1ThisGetsReallyLongAnd" +
                            "ILoveCamelCaseLettersHiProfessorHopeAllIsWell!I'mEnjoyingLearningAboutJUnitTesting");
        });
    }

    @Test
    void testGetDescription(){
        Appointment task = new Appointment("0123456789",currentDate, "AppointmentDescription1");
        assertTrue(task.getDescription().equals("AppointmentDescription1"));
    }

    @Test
    void testGetId(){
        Appointment task = new Appointment("0123456789",currentDate, "AppointmentDescription1");
        assertTrue(task.getId().equals("0123456789"));
    }

    @Test
    void testSetId(){
        Appointment task = new Appointment();
        task.setId("123456789");
        assertTrue(task.getId().equals("123456789"));
    }

    @Test
    void testSetDescription(){
        Appointment task = new Appointment();
        task.setDescription("GenericDescriptionhere");
        assertTrue(task.getDescription().equals("GenericDescriptionhere"));
    }
}