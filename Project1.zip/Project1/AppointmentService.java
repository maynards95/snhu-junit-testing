import java.util.ArrayList;
import java.util.Date;

public class AppointmentService {
    ArrayList<Appointment> data;

    public AppointmentService() {
        data = new ArrayList<Appointment>();
    }

    //add appointment method
    public boolean addAppointment(String id, Date appointmentDate, String description) {
        Appointment temp = Appointment.bookAppointment(id, appointmentDate, description);
        //checks if info is redundant or original, only adds if new data
        if (temp != null) {
            if (!data.contains(temp)) {
                data.add(temp);
                return true;
            }
        }
        return false;
    }

    //delete Appointment method
    public boolean deleteAppointment(String id) {
        //checks data ArrayList if id from input matches a stored appointment id
        for (Appointment temp : data) {
            //if id matches inputted id, remove id from data
            if (temp.getId().equals(id)) {
                data.remove(temp);
                return true;
            }
        }
        return false;
    }

}

