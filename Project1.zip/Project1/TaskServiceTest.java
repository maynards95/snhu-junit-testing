import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class TaskServiceTest {

    @Test
    void testAddTask(){
        TaskService ts = new TaskService();
        boolean task1 = ts.addTask("0123456789", "Task1", "TaskDescription1");
        assertEquals(true, task1);
    }

    @Test
    void testAddSameTaskID(){
        TaskService ts = new TaskService();
        boolean task1 = ts.addTask("0123456789", "Task1", "TaskDescription1");
        assertEquals(true, task1);
        boolean task2 = ts.addTask("0123456789", "Task2", "TaskDescription2");
        assertEquals(false, task2);
    }

    @Test
    void testDeleteTask(){
        TaskService ts = new TaskService();

        ts.addTask("0123456789", "Task1", "TaskDescription1");
        assertEquals(true,ts.deleteTask("0123456789"));
        //false because we already deleted this task.
        assertEquals(false,ts.deleteTask("0123456789"));
        //false because ID does not exist
        assertEquals(false,ts.deleteTask("012345678922"));
    }

    @Test
    void testUpdateName(){
        TaskService ts = new TaskService();

        ts.addTask("0123456789", "Task1", "TaskDescription1");
        try {
            assertEquals(true, ts.updateTaskName("0123456789", "NewTask"));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    void testUpdateNameWithWrongID(){
        TaskService ts = new TaskService();

        ts.addTask("0123456789", "Task1", "TaskDescription1");
        try {
            assertEquals(false, ts.updateTaskName("01234567899", "NewTaskName"));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    void testUpdateDescription(){
        TaskService ts = new TaskService();

        ts.addTask("0123456789", "Task1", "TaskDescription1");
        try {
            assertEquals(true, ts.updateTaskDescription("0123456789", "NewTaskDescriptionee"));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    void testUpdateDescriptionWithWrongID(){
        TaskService ts = new TaskService();

        ts.addTask("0123456789", "Task1", "TaskDescription1");
        try {
            assertEquals(false, ts.updateTaskDescription("01234567899", "NewTaskDescriptionheree"));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}