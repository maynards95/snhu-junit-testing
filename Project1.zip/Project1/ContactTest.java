import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ContactTest {
    Contact contact = new Contact("1", "Ezra", "Maynard", "123456789", "fake ave 1152");
    Contact contact2 = new Contact("1234567891011", "Ezraaaaaaaaaaaaa", "Maynardddddddddddddddd", "123456789444", "fake ave 1152 hello is this this on");
    @Test
    void getContactID() {
        assertEquals("1", contact.getContactID());
        // if contact ID is over 10 characters long print error in object
        assertEquals("Error: please update contact ID", contact2.getContactID());
    }

    @Test
    void getFirstName() {
        assertEquals("Ezra", contact.getFirstName());
        //if first name is over 10 characters long print error in object
        assertEquals("Error: Please update first name", contact2.getFirstName());
    }

    @Test
    void getLastName() {
        assertEquals("Maynard", contact.getLastName());
        // if last name is over 10 characters long print error in object
        assertEquals("Error: Please update last name", contact2.getLastName());
    }

    @Test
    void getPhoneNumber() {
        assertEquals("123456789", contact.getPhoneNumber());
        //If phone number is over 10 characters long print an error in object
        assertEquals("Error: Please update phone number", contact2.getPhoneNumber());
    }

    @Test
    void getAddress() {
        assertEquals("fake ave 1152", contact.getAddress());
        //If address is over 30 characters long print an error in object
        assertEquals("Error: Please update address", contact2.getAddress());
    }

    @Test
    void testToString() {
        assertEquals("Contact [contactID=1, firstName=Ezra, lastName=Maynard, phoneNumber=123456789, address=fake ave 1152]", contact.toString());
    }

    @Test
    void testEquals(){
        ContactService cs = new ContactService();
        Contact c1 = new Contact("C001", "Ezra", "May", "1234566970","121 LA ST");
        assertEquals(true, cs.addContact(c1));
        assertEquals(false, cs.addContact(c1));
    }
}