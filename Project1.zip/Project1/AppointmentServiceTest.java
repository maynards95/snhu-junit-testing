import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import java.util.Date;
class AppointmentServiceTest {

    Date currentDate = new Date();
    @Test
    void testDeleteTask(){
        AppointmentService as = new AppointmentService();
        as.addAppointment("0123456789", currentDate, "TaskDescription1");
        assertEquals(true,as.deleteAppointment("0123456789"));
        //false because we already deleted this task.
        assertEquals(false,as.deleteAppointment("0123456789"));
        //false because ID does not exist
        assertEquals(false,as.deleteAppointment("012345678922"));
    }

    @Test
    void testAddAppointment(){
        AppointmentService as = new AppointmentService();
        assertEquals(true,as.addAppointment("0123456789", currentDate, "TaskDescription1"));
        assertEquals(true,as.addAppointment("0123456744", currentDate, "TaskDescription2"));
        assertEquals(true,as.addAppointment("0123456744", currentDate, "TaskDescription2"));

    }

    @Test
    void testAppointmentDateInvalid(){
        AppointmentService as = new AppointmentService();
        assertEquals(false,as.addAppointment("0123456744", null ,"TaskDescription2"));
    }
}