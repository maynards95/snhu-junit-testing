import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class TaskTest {
    @Test
    void testTask(){
        Task task = new Task("0123456789", "Task1", "TaskDescription1");
        assertTrue(task.getTaskName().equals("Task1"));
        assertTrue(task.getId().equals("0123456789"));
        assertTrue(task.getTaskDescription().equals("TaskDescription1"));
    }

    @Test
    void testTaskIDTooLong(){
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Task("0123456789000", "Task2", "TaskDescription2");
        });
    }

    @Test
    void testTestNameTooLong() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Task("0123456789", "Task2Thisoneis way too long and should throw an error", "TaskDescription2");
        });
    }

    @Test
    void testDescriptionTooLong(){
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Task("0123456789", "Task2", "TaskDescription2 Ths " +
                    "one will be too long and over the limit for sure I Just have to " +
                    "keeping adding words");
        });
    }

    @Test
    void testSetTaskDescription(){
        Task task = new Task();
        task.setTaskDescription("TaskDescriptionagain");
        assertTrue(task.getTaskDescription().equals("TaskDescriptionagain"));
    }

    @Test
    void testSetTaskId(){
        Task task = new Task();
        task.setTaskName("TaskNameHere");
        assertTrue(task.getTaskName().equals("TaskNameHere"));
    }

    @Test
    void testGetId(){
        Task task = new Task();
        task.setTaskName("TaskNameHere");
        assertTrue(task.getTaskName().equals("TaskNameHere"));
    }

}