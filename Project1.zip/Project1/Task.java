
    public class Task {
        private String id;
        private String taskName;
        private String taskDescription;

        public Task(String id, String taskName, String taskDescription) {
            if (id.length() > 10 || id == null) {
                throw new IllegalArgumentException("Invalid input");
            }

            if (taskName == null || taskName.length() > 20) {
                throw new IllegalArgumentException("Invalid input");
            }

            if (taskDescription.length() > 50 || taskDescription == null) {
                throw new IllegalArgumentException("Invalid input");
            }
            this.id = id;
            this.taskName = taskName;
            this.taskDescription = taskDescription;
        }

        public Task() {

        }

        public static Task createTask(String id, String taskName, String description) {


            return new Task(id, taskName, description);
        }
        //GETTERS
        public String getTaskName() {
            return taskName;
        }
        public String getTaskDescription() {
            return taskDescription;
        }
        public String getId() {
            return id;
        }

        //SETTERS
        public void setTaskName(String taskName) {
            this.taskName = taskName;
        }

        public void setTaskDescription(String description) {
            this.taskDescription = description;
        }

    }
