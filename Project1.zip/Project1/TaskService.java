import java.util.ArrayList;

public class TaskService {
    ArrayList<Task> data;

    public TaskService() {
        data = new ArrayList<Task>();
    }

    //adds a Task with id, taskname, and taskdscription.
    public boolean addTask(String id, String taskName, String taskDescription) {
        Task temp = Task.createTask(id, taskName, taskDescription);

        for (Task t: data) {
            if (t.getId().equals(id)) {
                return false;
            }
        }
        if (temp != null) {
                if (!data.contains(temp)) {
                    data.add(temp);
                    return true;
                }
            }
        return false;
        }

    //deletes a task if id is found in data
    public boolean deleteTask(String id) {
        for (Task temp : data) {
            if (temp.getId().equals(id)) {
                data.remove(temp);
                return true;
            }
        }
        return false;
    }

    //Update task name with matching ID
    public boolean updateTaskName(String id, String taskName) throws Exception {
        boolean updated = false;
        for (Task t : data) {
            if (t.getId().equalsIgnoreCase(id)) {
                t.setTaskName(taskName);
                updated = true;
                break;
            }
        }
        return updated;
    }

    // Update Task Description with a matching iD
    public boolean updateTaskDescription(String id, String taskDescription) {
        boolean updated = false;
        for (Task t : data) {
            if (t.getId().equalsIgnoreCase(id)) {
                t.setTaskDescription(taskDescription);
                updated = true;
                break;
            }
        }
        return updated;
    }

}